LoRA image-classification adapter
=================================

This bundle is not a standalone model. Reconstruct the exact pretrained base listed in manifest.json, create the registered classifier head, attach LoRA using adapter_config.json, then load adapter_model.safetensors. The classifier head is included in that tensor file.
